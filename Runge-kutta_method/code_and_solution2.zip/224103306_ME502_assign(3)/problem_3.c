#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double fxyz(double); 
double gxyz(double,double);
double Yx(double);
double Zx(double);
double Rk4(double,double,double,double,int,double [],double []);

int main()
{ 
   //Y and Z values  
    
  double x0=1,y0=3,z0=0,L=6,h;
  int i, N;

  FILE *out_file = fopen("output_3.txt","w");

  fprintf(out_file,"Part (A)\n");
  for(N=0;N<=20;N++)
  {
       if(N==5 || N==10 || N==20)
       {  
          fprintf(out_file,"\nFor N = %d",N);
          fprintf(out_file,"\n\nX\t\tAnalytical_Y(x)\t\tY(x)_Rk4\t\tAnalytical_Z(x)\t\tZ(x)_Rk4\n\n");
  
          h = (L-x0)/N;
  
          double Y[N+2],Z[N+2];
          Rk4(x0,y0,z0,L,N,Y,Z);
  
          for(i=0;i<=N;i++)
          {
              fprintf(out_file,"%lf\t\t%lf\t\t%lf\t\t%lf\t\t%lf\n",(x0+i*h),Yx(x0+i*h),Y[i],Zx(x0+i*h),Z[i]);
          }
       }
  }
   //Error
   fprintf(out_file,"\nPart (B)\n\nThe Error for different values of N are\n");
   fprintf(out_file,"\nN\t\te_yL2\t\te_zL2\n\n");
   
   for(N=0;N<26;N++)
   {
       if(N==2 || N==5 || N==10 || N==15 || N==20 || N==25)
       {
           double Y[N+2],Z[N+2];
           Rk4(x0,y0,z0,L,N,Y,Z);
  
           fprintf(out_file,"%d\t\t%lf\t\t%lf\n",N,Y[N+1],Z[N+1]);
       }
   }
   fclose(out_file);
   printf("The solution file has been printed on Output_3.txt");
   
   
  return 0;
}

 // y' = f(x,y,z)

double fxyz(double z)
{
    return z;
}

// z' = g(x,y,z)

double gxyz(double x, double z)
{
    return (9*x*x + 3*z + -15)/x ;
}

//Analytical y(x)

double Yx(double x)
{
    return pow(x,4) + -3*pow(x,3) + 5*x ;
}

//Analytical z(x)

double Zx(double x)
{
    return 4*pow(x,3) - 9*x*x +5 ;
}


// Runge kutta order 4  

double Rk4(double x0, double y0,double z0,double L, int N,double Y[],double Z[])
{
    double h,esumu=0,esumv=0,k1,l1,k2,l2,k3,l3,k4,l4;
    
    h = (L-x0)/N;

    Y[0] = y0;
    Z[0] = z0;
    
    int i;
    for(i=0;i<N;i++)
    {
      k1 = h*fxyz(Z[i]);
      l1 = h*gxyz(x0,Z[i]);
    
      k2 = h*fxyz(Z[i]+0.5*l1);
      l2 = h*gxyz(x0+0.5*h,Z[i]+0.5*l1);
    
      k3 = h*fxyz(Z[i]+0.5*l2);
      l3 = h*gxyz(x0+0.5*h,Z[i]+0.5*l2);
    
      k4 = h*fxyz(Z[i]+l3);
      l4 = h*gxyz(x0+h,Z[i]+l3);
    
      Y[i+1] = Y[i] + (k1 + 2*k2 + 2*k3 + k4)/6;
      Z[i+1] = Z[i] + (l1 + 2*l2 + 2*l3 + l4)/6;
      
      esumu = esumu + pow((Y[i+1] - Yx(x0+h)),2);
      esumv = esumv + pow((Z[i+1] - Zx(x0+h)),2); 
      
      x0 = x0 + h;
      
    }
    Y[N+1] = sqrt(esumu)/N;
    Z[N+1] = sqrt(esumv)/N;
    
  
  
}
