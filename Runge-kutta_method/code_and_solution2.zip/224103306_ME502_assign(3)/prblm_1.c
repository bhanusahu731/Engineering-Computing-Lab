#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double prob_1_gx(double);
double prob_1_fxy(double,double);

double Euler(double,double,double,int,double []);
double MidPoint(double,double,double,int,double []);
double RK_2(double,double,double,int,double []);
double RK_4(double,double,double,int,double []);

int main()
{   double x0 = 1,y0 = 4, L=6,h;
    
    int j,N;
    FILE *out_file = fopen("output_1.txt","w");
 
    fprintf(out_file,"part (a)\n");
 
    for(N=0;N<=25;N++) 
    {
    if(N==5 || N==10 || N==20)
    {
    fprintf(out_file,"\nThe Y values for N = %d\n",N);
    h = (L-x0)/N;
    
    double Y1[N+2];
    Euler(x0,y0,L,N,Y1);
    
    double Y2[N+2];
    MidPoint(x0,y0,L,N,Y2);
   
    double Y3[N+2];
    RK_2(x0,y0,L,N,Y3);

    double Y4[N+2];
    RK_4(x0,y0,L,N,Y4);

    fprintf(out_file,"X\t\tY(Analytical)\t\tY(Euler)\t\tY(Mid point)\t\tY(RK_2)\t\tY(RK_4)\n\n");
    
    for(j=0;j<=N;j++)
    {
        fprintf(out_file,"%lf\t\t%f\t\t%lf\t\t%lf\t\t%lf\t\t%lf\n",x0+j*h,prob_1_gx(x0+j*h),Y1[j],Y2[j],Y3[j],Y4[j]);
    }
    
    }
    
    }
    fprintf(out_file,"\nPart (b)\n\nThe Error from different methods are\n\nN\t\t(Euler)\t\t(Mid point)\t\t(RK_2)\t\t(RK_4)\n\n");
    
    for(N=0;N<=25;N++)
    {
    if(N==2 || N==5 || N==10 || N==15 || N==20 || N==25)
    {
   
    double Y1[N+2];
    Euler(x0,y0,L,N,Y1);
    
    double Y2[N+2];
    MidPoint(x0,y0,L,N,Y2);
   
    double Y3[N+2];
    RK_2(x0,y0,L,N,Y3);

    double Y4[N+2];
    RK_4(x0,y0,L,N,Y4);

    fprintf(out_file,"%d\t\t%f\t\t%lf\t\t%lf\t\t%lf\n",N,Y1[N+1],Y2[N+1],Y3[N+1],Y4[N+1]);
    }
    
    }
    fclose(out_file);
    printf("The solution file has been printed in Output_1.txt");
    return 0;
}

//problem 1 

double prob_1_fxy(double x,double y)
{
    double fxy = (4*pow(x,4)) + (y/x);
    return fxy;
}

double prob_1_gx(double x)
{
 double gxy = pow(x,5) + 3*x ;  
 return gxy;
}


//Euler method

double Euler(double x0,double y0, double L, int N,double Y[])
{
    double h = (L-x0)/N;
    double esum=0;
    Y[0] = y0;
    
    int i;
    
    for(i=0;i<N;i++)
    {
      Y[i+1] = Y[i] + h* prob_1_fxy(x0,Y[i]);
        
      x0 = x0 + h;
      esum=esum+pow((Y[i+1] -prob_1_gx(x0)),2);
        
    }
    //Error
    Y[N+1] = sqrt(esum)/N;
    
}

//Mid poit method

double MidPoint(double x0,double y0,double L,int N,double Y[])
{
    double h = (L-x0)/N ;
    double esum=0;
    Y[0] = y0;
    
    Y[1] = y0 + h*prob_1_fxy(x0,y0);
    
    x0 = x0 + h;
    
    esum = pow( (Y[1]-prob_1_gx(x0+h)) ,2);
    
    int i;
    for(i=1;i<N;i++)
    {
        Y[i+1] = Y[i-1] + 2*h*prob_1_fxy(x0,Y[i]);
        
        x0 = x0 +h;
        esum=esum+pow((Y[i+1] -prob_1_gx(x0)),2);
       
    }
    //Error
    Y[N+1]= sqrt(esum)/N;
  
}

//Runge Kutta 2nd order

double RK_2(double x0,double y0,double L,int N,double Y[])
{
    double h = (L-x0)/N ; 
    double esum=0;
    Y[0] = y0;
   
   int i;
   double k1,k2;
   for(i=0;i<N;i++)
   {
     k1 = h*prob_1_fxy(x0,Y[i]);
     k2 = h*prob_1_fxy( (x0+h) , (Y[i]+k1) );
    
     
     Y[i+1] = Y[i] + ( (k1+k2)/2) ;
     
     x0 = x0 + h;
     esum = esum + pow( (Y[i+1] - prob_1_gx(x0)) , 2);
     
   }
     //Error
     Y[N+1] = sqrt(esum)/N;
     
}

//Runge kutta 4th order

double RK_4(double x0,double y0,double L,int N,double Y[])
{
   double h = (L-x0)/N ; 
   double esum=0;
   Y[0] = y0;
   
   int i;
   for(i=0;i<N;i++)
   {
     double k1,k2,k3,k4;
     
     k1 = h*prob_1_fxy(x0,Y[i]);
     k2 = h*prob_1_fxy( (x0+0.5*h) , (Y[i]+0.5*k1) );
     k3 = h*prob_1_fxy( (x0+0.5*h) , (Y[i]+0.5*k2) );
     k4 = h*prob_1_fxy( (x0+h) , (Y[i]+k3) );
     
     Y[i+1] = Y[i] + ( (k1+2*k2+2*k3+k4)/6 ) ;
     
     x0 = x0 + h;
     
     esum = esum + pow( (Y[i+1] - prob_1_gx(x0)) , 2);
     
     
   }
     //Error
     Y[N+1] = sqrt(esum)/N;
     
}

